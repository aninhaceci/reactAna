import { useState } from "react";

export default function CampoTexto(props){

        const escreveu = (event) => {
            console.log(event.target.value);
        }
    return(
       <>
       <div>
       <label>{props.label}: </label>
       <input onChange ={escreveu} type="text" name={props.name} placeholder={props.place}/> <br/>
       </div>



       </> 
    );    
}