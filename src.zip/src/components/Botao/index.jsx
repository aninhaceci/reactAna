export default function Botao(props){
    return(
        <>
        <button>{props.children}</button>
        </>
    );
}