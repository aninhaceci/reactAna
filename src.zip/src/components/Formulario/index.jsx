import Botao from "../Botao";
import CampoTexto from "../CampoTexto";

export default function Formulario(){

const aoSubmeter = (evento) => {
    evento.preventDefault(); //pra realmente aparecer no console
    console.log("Formulário submetido");
}

    return (
        <>
        <h2>Cadastro de Pessoas</h2>
        <form onSubmit={aoSubmeter}>
            <CampoTexto label="Nome" nome="nome" place="Digite o nome" />
            <br/>
            <CampoTexto label="E-mail" nome="email" place="Digite o e-mail"/>
            <br/>
            <CampoTexto label="Telefone" nome="telefone" place="Digite o telefone"/>
            <br/>
           <Botao>Cadastrar Pessoa</Botao>
        </form>
        </>
    );
}